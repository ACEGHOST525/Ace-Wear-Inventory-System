# Ace Wear Inventory System

A lightweight PHP + MySQL web app for managing Ace Wear's stock and daily sales.

## Requirements
- PHP 7.4+ (works with XAMPP, WAMP, MAMP, or any PHP host)
- MySQL / MariaDB

## Setup

1. **Create the database.**
   In phpMyAdmin (or the MySQL CLI), import `database/schema.sql`. This creates
   the `acewear_db` database and the `admins`, `products`, and `sales` tables.

2. **Set your DB credentials.**
   Open `config/database.php` and update `DB_HOST`, `DB_USER`, `DB_PASS` if they
   differ from the defaults (`localhost` / `root` / empty password — the usual
   XAMPP defaults).

3. **Place the project in your server's web root**, e.g.
   `C:\xampp\htdocs\acewear` (Windows/XAMPP) or `htdocs/acewear` on Mac.

4. **Create your first admin account.**
   Visit `http://localhost/acewear/setup.php` in your browser, fill in the
   form, then **delete `setup.php`** — it should not stay on a live site.

5. **Log in** at `http://localhost/acewear/login.php` and start adding products.

## Project Structure

```
acewear/
├── config/database.php     PDO connection
├── includes/auth.php       session/login guard
├── includes/header.php     shared nav/header
├── includes/footer.php     shared footer
├── database/schema.sql     table definitions
├── index.php                dashboard
├── products.php             product catalog (add/edit/delete)
├── sell.php                  record a sale (deducts stock)
├── sales_history.php        transaction log
├── login.php / logout.php   authentication
├── setup.php                 one-time admin creation (delete after use)
└── assets/                   CSS and JS
```

## How it maps to the project proposal

- **products, sales, admins tables** — see `database/schema.sql`, with foreign
  keys linking sales to both the product sold and the admin who sold it.
- **Automatic stock deduction** — `sell.php` runs the insert-into-sales and
  update-products-quantity queries inside a single database transaction, so
  stock and sales records never fall out of sync.
- **Low-stock alerts** — each product has a `low_stock_threshold`; the
  dashboard highlights any product at or below it, color-coded red at zero.
- **Daily sales/profit summary** — the dashboard aggregates `sales` rows for
  `CURDATE()`, calculating profit from the price/cost snapshots stored on
  each sale (so it stays accurate even if you later change a product's price).
- **Sales history** — `sales_history.php` lists every transaction with a
  date filter and running totals.

## Suggested next steps (ideas for extending it further)

- Add a "category totals" or "best-selling size" report for your write-up.
- Export sales history to CSV.
- Add password-change functionality for the admin account.
- Add pagination to the product/sales tables once you have real data volume.
