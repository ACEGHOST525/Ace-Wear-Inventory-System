document.addEventListener('DOMContentLoaded', function () {
    const productSelect = document.getElementById('product_id');
    const qtyInput = document.getElementById('quantity_sold');
    const stockHint = document.getElementById('stock-hint');
    const totalHint = document.getElementById('total-hint');

    if (!productSelect) return;

    function updateHints() {
        const opt = productSelect.options[productSelect.selectedIndex];
        if (!opt || !opt.value) {
            stockHint.textContent = '';
            totalHint.style.display = 'none';
            return;
        }
        const stock = parseInt(opt.dataset.stock, 10);
        const price = parseFloat(opt.dataset.price);
        qtyInput.max = stock;
        stockHint.textContent = stock + ' unit(s) currently in stock.';

        const qty = parseInt(qtyInput.value, 10) || 0;
        if (qty > 0) {
            totalHint.style.display = 'block';
            totalHint.textContent = 'Total: ₦' + (qty * price).toLocaleString(undefined, { minimumFractionDigits: 2 });
        } else {
            totalHint.style.display = 'none';
        }

        if (qty > stock) {
            stockHint.textContent += ' ⚠ Quantity exceeds available stock!';
            stockHint.style.color = '#dc2626';
        } else {
            stockHint.style.color = '';
        }
    }

    productSelect.addEventListener('change', updateHints);
    qtyInput.addEventListener('input', updateHints);
});
