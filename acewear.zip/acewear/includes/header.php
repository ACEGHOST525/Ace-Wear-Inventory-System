<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ace Wear Inventory System</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-brand">Ace Wear</div>
    <div class="nav-links">
        <a href="index.php">Dashboard</a>
        <a href="products.php">Products</a>
        <a href="sell.php">Record Sale</a>
        <a href="sales_history.php">Sales History</a>
    </div>
    <div class="nav-user">
        <span><?= htmlspecialchars(currentAdminName()) ?></span>
        <a href="logout.php" class="logout-link">Logout</a>
    </div>
</nav>
<main class="container">
