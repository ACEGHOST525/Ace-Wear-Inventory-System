<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
requireLogin();

$pdo = getDB();

// Today's sales summary
$todayStmt = $pdo->query("
    SELECT
        COALESCE(SUM(total_amount), 0) AS total_sales,
        COALESCE(SUM((unit_price - unit_cost) * quantity_sold), 0) AS total_profit,
        COUNT(*) AS transaction_count
    FROM sales
    WHERE DATE(sold_at) = CURDATE()
");
$today = $todayStmt->fetch();

// Low stock items
$lowStockStmt = $pdo->query("
    SELECT * FROM products
    WHERE quantity <= low_stock_threshold
    ORDER BY quantity ASC
");
$lowStock = $lowStockStmt->fetchAll();

// Total product count and total stock value
$overviewStmt = $pdo->query("
    SELECT COUNT(*) AS product_count, COALESCE(SUM(quantity), 0) AS total_units
    FROM products
");
$overview = $overviewStmt->fetch();

// Best selling products (all-time, top 5)
$bestSellersStmt = $pdo->query("
    SELECT p.product_name, SUM(s.quantity_sold) AS units_sold
    FROM sales s
    JOIN products p ON p.product_id = s.product_id
    GROUP BY s.product_id
    ORDER BY units_sold DESC
    LIMIT 5
");
$bestSellers = $bestSellersStmt->fetchAll();

require_once 'includes/header.php';
?>

<h1>Dashboard</h1>

<div class="stat-grid">
    <div class="stat-card">
        <span class="stat-label">Today's Sales</span>
        <span class="stat-value">₦<?= number_format($today['total_sales'], 2) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Today's Estimated Profit</span>
        <span class="stat-value">₦<?= number_format($today['total_profit'], 2) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Transactions Today</span>
        <span class="stat-value"><?= (int)$today['transaction_count'] ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Products in Catalog</span>
        <span class="stat-value"><?= (int)$overview['product_count'] ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Units in Stock</span>
        <span class="stat-value"><?= (int)$overview['total_units'] ?></span>
    </div>
</div>

<div class="panel-grid">
    <div class="panel">
        <h2>⚠ Low Stock Alerts</h2>
        <?php if (empty($lowStock)): ?>
            <p class="muted">No items are low on stock right now.</p>
        <?php else: ?>
            <table>
                <tr><th>Product</th><th>Size</th><th>Color</th><th>Qty Left</th></tr>
                <?php foreach ($lowStock as $item): ?>
                <tr class="<?= $item['quantity'] == 0 ? 'row-danger' : 'row-warning' ?>">
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td><?= htmlspecialchars($item['size']) ?></td>
                    <td><?= htmlspecialchars($item['color']) ?></td>
                    <td><?= (int)$item['quantity'] ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="panel">
        <h2>Top Selling Products</h2>
        <?php if (empty($bestSellers)): ?>
            <p class="muted">No sales recorded yet.</p>
        <?php else: ?>
            <table>
                <tr><th>Product</th><th>Units Sold</th></tr>
                <?php foreach ($bestSellers as $b): ?>
                <tr>
                    <td><?= htmlspecialchars($b['product_name']) ?></td>
                    <td><?= (int)$b['units_sold'] ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
