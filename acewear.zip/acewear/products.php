<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
requireLogin();

$pdo = getDB();
$message = '';

// --- Handle Add / Edit ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $productId   = $_POST['product_id'] ?? '';
    $name        = trim($_POST['product_name'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $size        = trim($_POST['size'] ?? '');
    $color       = trim($_POST['color'] ?? '');
    $quantity    = (int)($_POST['quantity'] ?? 0);
    $threshold   = (int)($_POST['low_stock_threshold'] ?? 5);
    $unitCost    = (float)($_POST['unit_cost'] ?? 0);
    $sellPrice   = (float)($_POST['selling_price'] ?? 0);

    if ($name === '' || $category === '') {
        $message = 'Product name and category are required.';
    } else {
        if ($productId) {
            $stmt = $pdo->prepare("
                UPDATE products SET product_name=?, category=?, size=?, color=?,
                quantity=?, low_stock_threshold=?, unit_cost=?, selling_price=?
                WHERE product_id=?
            ");
            $stmt->execute([$name, $category, $size, $color, $quantity, $threshold, $unitCost, $sellPrice, $productId]);
            $message = 'Product updated.';
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO products (product_name, category, size, color, quantity, low_stock_threshold, unit_cost, selling_price)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $category, $size, $color, $quantity, $threshold, $unitCost, $sellPrice]);
            $message = 'Product added.';
        }
    }
}

// --- Handle Delete ---
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM products WHERE product_id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header('Location: products.php');
    exit;
}

// --- Load product being edited (if any) ---
$editing = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editing = $stmt->fetch();
}

// --- Search / filter ---
$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_name LIKE ? OR category LIKE ? ORDER BY product_name");
    $like = "%$search%";
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY product_name");
}
$products = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<h1>Product Catalog</h1>
<?php if ($message): ?><p class="success"><?= htmlspecialchars($message) ?></p><?php endif; ?>

<div class="panel">
    <h2><?= $editing ? 'Edit Product' : 'Add New Product' ?></h2>
    <form method="POST" class="product-form">
        <input type="hidden" name="action" value="save">
        <?php if ($editing): ?>
            <input type="hidden" name="product_id" value="<?= (int)$editing['product_id'] ?>">
        <?php endif; ?>
        <div class="form-grid">
            <div><label>Product Name</label><input type="text" name="product_name" value="<?= htmlspecialchars($editing['product_name'] ?? '') ?>" required></div>
            <div><label>Category</label><input type="text" name="category" value="<?= htmlspecialchars($editing['category'] ?? '') ?>" placeholder="Shirt, Trouser, Denim, Accessory" required></div>
            <div><label>Size</label><input type="text" name="size" value="<?= htmlspecialchars($editing['size'] ?? '') ?>"></div>
            <div><label>Color</label><input type="text" name="color" value="<?= htmlspecialchars($editing['color'] ?? '') ?>"></div>
            <div><label>Quantity</label><input type="number" name="quantity" min="0" value="<?= htmlspecialchars($editing['quantity'] ?? 0) ?>" required></div>
            <div><label>Low Stock Alert Level</label><input type="number" name="low_stock_threshold" min="0" value="<?= htmlspecialchars($editing['low_stock_threshold'] ?? 5) ?>"></div>
            <div><label>Unit Cost (₦)</label><input type="number" step="0.01" name="unit_cost" value="<?= htmlspecialchars($editing['unit_cost'] ?? 0) ?>" required></div>
            <div><label>Selling Price (₦)</label><input type="number" step="0.01" name="selling_price" value="<?= htmlspecialchars($editing['selling_price'] ?? 0) ?>" required></div>
        </div>
        <button type="submit"><?= $editing ? 'Update Product' : 'Add Product' ?></button>
        <?php if ($editing): ?><a href="products.php" class="btn-secondary">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="panel">
    <div class="panel-header">
        <h2>All Products</h2>
        <form method="GET" class="search-form">
            <input type="text" name="q" placeholder="Search by name or category..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit">Search</button>
        </form>
    </div>
    <table>
        <tr>
            <th>Name</th><th>Category</th><th>Size</th><th>Color</th>
            <th>Qty</th><th>Cost</th><th>Price</th><th>Actions</th>
        </tr>
        <?php foreach ($products as $p): ?>
        <tr class="<?= $p['quantity'] <= $p['low_stock_threshold'] ? 'row-warning' : '' ?>">
            <td><?= htmlspecialchars($p['product_name']) ?></td>
            <td><?= htmlspecialchars($p['category']) ?></td>
            <td><?= htmlspecialchars($p['size']) ?></td>
            <td><?= htmlspecialchars($p['color']) ?></td>
            <td><?= (int)$p['quantity'] ?></td>
            <td>₦<?= number_format($p['unit_cost'], 2) ?></td>
            <td>₦<?= number_format($p['selling_price'], 2) ?></td>
            <td>
                <a href="products.php?edit=<?= (int)$p['product_id'] ?>">Edit</a> |
                <a href="products.php?delete=<?= (int)$p['product_id'] ?>" class="danger-link" onclick="return confirm('Delete this product?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
        <tr><td colspan="8" class="muted">No products found.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>
