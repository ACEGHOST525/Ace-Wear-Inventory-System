<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
requireLogin();

$pdo = getDB();

$dateFilter = $_GET['date'] ?? '';

$sql = "
    SELECT s.*, p.product_name, p.category, a.full_name AS sold_by
    FROM sales s
    JOIN products p ON p.product_id = s.product_id
    JOIN admins a ON a.admin_id = s.admin_id
";
$params = [];
if ($dateFilter !== '') {
    $sql .= " WHERE DATE(s.sold_at) = ?";
    $params[] = $dateFilter;
}
$sql .= " ORDER BY s.sold_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$sales = $stmt->fetchAll();

$totalRevenue = 0;
$totalProfit = 0;
foreach ($sales as $s) {
    $totalRevenue += $s['total_amount'];
    $totalProfit += ($s['unit_price'] - $s['unit_cost']) * $s['quantity_sold'];
}

require_once 'includes/header.php';
?>

<h1>Sales History</h1>

<div class="panel">
    <form method="GET" class="search-form">
        <label>Filter by date</label>
        <input type="date" name="date" value="<?= htmlspecialchars($dateFilter) ?>">
        <button type="submit">Filter</button>
        <?php if ($dateFilter): ?><a href="sales_history.php" class="btn-secondary">Clear</a><?php endif; ?>
    </form>
</div>

<div class="stat-grid">
    <div class="stat-card">
        <span class="stat-label">Total Revenue<?= $dateFilter ? '' : ' (All Time)' ?></span>
        <span class="stat-value">₦<?= number_format($totalRevenue, 2) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Total Profit<?= $dateFilter ? '' : ' (All Time)' ?></span>
        <span class="stat-value">₦<?= number_format($totalProfit, 2) ?></span>
    </div>
    <div class="stat-card">
        <span class="stat-label">Transactions</span>
        <span class="stat-value"><?= count($sales) ?></span>
    </div>
</div>

<div class="panel">
    <table>
        <tr>
            <th>Date/Time</th><th>Product</th><th>Category</th>
            <th>Qty</th><th>Unit Price</th><th>Total</th><th>Sold By</th>
        </tr>
        <?php foreach ($sales as $s): ?>
        <tr>
            <td><?= htmlspecialchars(date('d M Y, h:i A', strtotime($s['sold_at']))) ?></td>
            <td><?= htmlspecialchars($s['product_name']) ?></td>
            <td><?= htmlspecialchars($s['category']) ?></td>
            <td><?= (int)$s['quantity_sold'] ?></td>
            <td>₦<?= number_format($s['unit_price'], 2) ?></td>
            <td>₦<?= number_format($s['total_amount'], 2) ?></td>
            <td><?= htmlspecialchars($s['sold_by']) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($sales)): ?>
        <tr><td colspan="7" class="muted">No sales recorded<?= $dateFilter ? ' for this date' : '' ?>.</td></tr>
        <?php endif; ?>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>
