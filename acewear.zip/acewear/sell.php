<?php
require_once 'includes/auth.php';
require_once 'config/database.php';
requireLogin();

$pdo = getDB();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = (int)($_POST['product_id'] ?? 0);
    $qtySold   = (int)($_POST['quantity_sold'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM products WHERE product_id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();

    if (!$product) {
        $error = 'Product not found.';
    } elseif ($qtySold <= 0) {
        $error = 'Quantity sold must be at least 1.';
    } elseif ($qtySold > $product['quantity']) {
        $error = 'Not enough stock. Only ' . $product['quantity'] . ' left.';
    } else {
        $pdo->beginTransaction();
        try {
            $total = $qtySold * $product['selling_price'];

            $insert = $pdo->prepare("
                INSERT INTO sales (product_id, admin_id, quantity_sold, unit_price, unit_cost, total_amount)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $insert->execute([
                $productId,
                $_SESSION['admin_id'],
                $qtySold,
                $product['selling_price'],
                $product['unit_cost'],
                $total
            ]);

            $update = $pdo->prepare("UPDATE products SET quantity = quantity - ? WHERE product_id = ?");
            $update->execute([$qtySold, $productId]);

            $pdo->commit();
            $message = "Sale recorded: {$qtySold} x {$product['product_name']} — ₦" . number_format($total, 2);
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Something went wrong recording the sale.';
        }
    }
}

$products = $pdo->query("SELECT * FROM products WHERE quantity > 0 ORDER BY product_name")->fetchAll();

require_once 'includes/header.php';
?>

<h1>Record a Sale</h1>
<?php if ($message): ?><p class="success"><?= htmlspecialchars($message) ?></p><?php endif; ?>
<?php if ($error): ?><p class="error"><?= htmlspecialchars($error) ?></p><?php endif; ?>

<div class="panel">
    <form method="POST" class="product-form" id="sale-form">
        <label>Product</label>
        <select name="product_id" id="product_id" required>
            <option value="">-- Select a product --</option>
            <?php foreach ($products as $p): ?>
                <option value="<?= (int)$p['product_id'] ?>"
                    data-price="<?= htmlspecialchars($p['selling_price']) ?>"
                    data-stock="<?= (int)$p['quantity'] ?>">
                    <?= htmlspecialchars($p['product_name']) ?>
                    <?= $p['size'] ? '(' . htmlspecialchars($p['size']) . ($p['color'] ? ', ' . htmlspecialchars($p['color']) : '') . ')' : '' ?>
                    — ₦<?= number_format($p['selling_price'], 2) ?> — <?= (int)$p['quantity'] ?> in stock
                </option>
            <?php endforeach; ?>
        </select>

        <label>Quantity Sold</label>
        <input type="number" name="quantity_sold" id="quantity_sold" min="1" required>

        <p id="stock-hint" class="muted"></p>
        <p id="total-hint" class="stat-value" style="display:none;"></p>

        <button type="submit">Confirm Sale</button>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>
