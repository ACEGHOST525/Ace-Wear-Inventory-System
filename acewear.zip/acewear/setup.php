<?php
// Run this ONCE after creating the database (import database/schema.sql first),
// then DELETE this file. It creates your first admin login.
require_once 'config/database.php';

$message = '';
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($fullName === '' || $username === '' || $password === '') {
        $message = 'All fields are required.';
    } else {
        $pdo = getDB();
        $check = $pdo->prepare("SELECT admin_id FROM admins WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $message = 'That username is already taken.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO admins (full_name, username, password_hash) VALUES (?, ?, ?)");
            $stmt->execute([$fullName, $username, $hash]);
            $done = true;
            $message = 'Admin account created. You can now delete setup.php and log in.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Ace Wear - Setup</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="auth-box">
    <h2>Create First Admin Account</h2>
    <?php if ($message): ?>
        <p class="<?= $done ? 'success' : 'error' ?>"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <?php if (!$done): ?>
    <form method="POST">
        <label>Full Name</label>
        <input type="text" name="full_name" required>
        <label>Username</label>
        <input type="text" name="username" required>
        <label>Password</label>
        <input type="password" name="password" required>
        <button type="submit">Create Admin</button>
    </form>
    <?php else: ?>
        <a href="login.php">Go to Login</a>
    <?php endif; ?>
</div>
</body>
</html>
